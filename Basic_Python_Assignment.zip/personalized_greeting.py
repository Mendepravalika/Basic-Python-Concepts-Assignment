# personalized_greeting.py

# Get user input
first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

# Concatenate names
full_name = first_name + " " + last_name

# Display greeting
print(f"\nHello, {full_name}! Welcome to the Python world!")
